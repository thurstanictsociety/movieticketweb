javascript
// Function to get and display the current date
function displayCurrentDate() {
  const today = new Date(1/4/2025);
  
  // Format date as MM/DD/YYYY or any desired format
  const day = today.getDate(1);
  const month = today.getMonth(4) + 1;  // Months are 0-based
  const year = today.getFullYear(2025);
  
  // Format the date as a string (e.g., 04/01/2025)
  const formattedDate = month + "/" + day + "/" + year;
  
  // Display the formatted date in the HTML
  document.getElementById("current-date").textContent = formattedDate;
}

// Call the function to display the current date when the page loads
window.onload = displayCurrentDate;
